import{_ as Z}from"./_plugin-vue_export-helper-DlAUqK2U.js";import{c as B,o as v,a as L,k as N,l as g,m as G,t as R,F as M,b as w,z as Q,y as p,s as y,a0 as $,g as F,j as E,h as x,f as A,W as k,w as b,T as z,v as O,C as S,x as D,a1 as I,a2 as H,a3 as W,a4 as Y,i as T,I as q,J,a5 as K,a6 as U,a7 as X,a8 as j,a9 as ee,K as te,aa as ae,ab as ne,ac as se,ad as oe,M as re,ae as le,af as ie,N as ce,ag as ue,ah as me,ai as fe,O as de}from"./index-Bnu2ge-9.js";import{T as V}from"./index-C1_EnFUq.js";import{V as ge,a as he}from"./VList-CwGfKth6.js";import{V as ve}from"./VMenu-D6Lx_LmM.js";const Le=(e="#8C57FF")=>{const t=`
  <svg class="svg-canvas" viewBox="100 100 600 400" width="800" height="600" preserveAspectRatio="none" version="1.1"
     xmlns="http://www.w3.org/2000/svg">
  <g id="shape_Y1MFRqHJ6u" mask="">
    <g transform="translate(120,135.97354382365) rotate(0,280,164.02645617635) scale(1,1)"
       style="opacity: 1;mix-blend-mode: undefined;" filter="">
      <svg data-noselect="" viewBox="222.29009226667768 82.52330644317703 383.19672 224.48000000000002" width="560"
           height="328.05291235269" preserveAspectRatio="none" version="1.1" xmlns="http://www.w3.org/2000/svg"
           style="background: transparent;" class="style-removed" data-parent="shape_Y1MFRqHJ6u">
        <g id="shape_GhDKMseSsz" class="icon custom-icon text brand_word_letter" mask="">
          <g transform="translate(-195.58618432116998,-562.944415548383) rotate(0,703.44772199156,756.94772199156) scale(1,1)"
             style="" filter="" cursor="move" display="inline" opacity="1">
            <g style="" display="inline">
              <svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="1406.89544398312" height="1513.89544398312"
                   viewBox="0 0 1406.89544398312 1513.89544398312" data-ligature="true" preserveAspectRatio="none"
                   data-parent="shape_GhDKMseSsz">
                <g transform="translate(631.2029965878477, 630.94772199156)">
                  <path
                    d="M55.73 0L18.09 0L18.09-156.48L72.98-156.48Q90.23-156.48 104.53-151.85Q118.83-147.22 127.35-136.08Q135.87-124.93 135.87-105.58L135.87-105.58Q135.87-87.07 127.24-75.19Q118.62-63.31 104.63-57.63Q90.65-51.95 74.03-51.95L74.03-51.95L55.73-51.95L55.73 0ZM55.73-126.82L55.73-81.60L72.14-81.60Q85.81-81.60 92.54-87.81Q99.27-94.01 99.27-105.58L99.27-105.58Q99.27-117.36 92.02-122.09Q84.76-126.82 71.09-126.82L71.09-126.82L55.73-126.82Z"
                    transform="translate(0 205) " fill="${e}" stroke="${e}" stroke-width="33.351"
                    stroke-miterlimit="3"></path>
                </g>
                <g transform="translate(631.2029965878477, 630.94772199156)">
                  <path
                    d="M55.73 0L18.09 0L18.09-156.48L72.98-156.48Q90.23-156.48 104.53-151.85Q118.83-147.22 127.35-136.08Q135.87-124.93 135.87-105.58L135.87-105.58Q135.87-87.07 127.24-75.19Q118.62-63.31 104.63-57.63Q90.65-51.95 74.03-51.95L74.03-51.95L55.73-51.95L55.73 0ZM55.73-126.82L55.73-81.60L72.14-81.60Q85.81-81.60 92.54-87.81Q99.27-94.01 99.27-105.58L99.27-105.58Q99.27-117.36 92.02-122.09Q84.76-126.82 71.09-126.82L71.09-126.82L55.73-126.82Z"
                    transform="translate(0 205) " fill="#ffffff" stroke="#ffffff" stroke-width="0.351"></path>
                </g>
              </svg>
            </g>
          </g>
        </g>
        <g id="shape_m5SrZGu7uo" class="icon custom-icon text brand_word_letter"
           mask="">
          <g transform="translate(-312.08618432117,-562.944415548383) rotate(0,723.44772199156,756.94772199156) scale(1,1)"
             style="" filter="" cursor="move" display="inline" opacity="1">
            <g style="" display="inline">
              <svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="1446.89544398312" height="1513.89544398312"
                   viewBox="0 0 1446.89544398312 1513.89544398312" data-ligature="true" preserveAspectRatio="none"
                   data-parent="shape_m5SrZGu7uo">
                <g transform="translate(631.2225965878476, 630.94772199156)">
                  <path
                    d="M51.74 0L18.09 0L18.09-156.48L58.68-156.48L83.50-88.97Q86.44-80.13 89.18-70.67L89.18-70.67Q90.65-65.62 92.12-60.36L92.12-60.36L93.17-60.36Q95.49-67.72 97.59-75.29L97.59-75.29Q99.69-82.24 101.79-88.97L101.79-88.97L125.77-156.48L166.57-156.48L166.57 0L132.29 0L132.29-53.63Q132.29-64.99 133.87-79.71Q135.45-94.43 136.92-106.42L136.92-106.42Q137.13-107.26 137.13-107.89L137.13-107.89L136.29-107.89L123.25-70.46L102.22-13.25L81.60-13.25L60.36-70.46L47.74-107.89L46.90-107.89Q46.90-107.26 47.11-106.42L47.11-106.42Q48.58-94.43 50.16-79.71Q51.74-64.99 51.74-53.63L51.74-53.63L51.74 0Z"
                    transform="translate(0 205) " fill="${e}" stroke="${e}" stroke-width="33.351"
                    stroke-miterlimit="3"></path>
                </g>
                <g transform="translate(631.2225965878476, 630.94772199156)">
                  <path
                    d="M51.74 0L18.09 0L18.09-156.48L58.68-156.48L83.50-88.97Q86.44-80.13 89.18-70.67L89.18-70.67Q90.65-65.62 92.12-60.36L92.12-60.36L93.17-60.36Q95.49-67.72 97.59-75.29L97.59-75.29Q99.69-82.24 101.79-88.97L101.79-88.97L125.77-156.48L166.57-156.48L166.57 0L132.29 0L132.29-53.63Q132.29-64.99 133.87-79.71Q135.45-94.43 136.92-106.42L136.92-106.42Q137.13-107.26 137.13-107.89L137.13-107.89L136.29-107.89L123.25-70.46L102.22-13.25L81.60-13.25L60.36-70.46L47.74-107.89L46.90-107.89Q46.90-107.26 47.11-106.42L47.11-106.42Q48.58-94.43 50.16-79.71Q51.74-64.99 51.74-53.63L51.74-53.63L51.74 0Z"
                    transform="translate(0 205) " fill="#ffffff" stroke="#ffffff" stroke-width="0.351"></path>
                </g>
              </svg>
            </g>
          </g>
        </g>
        <g id="shape_MBN9cAwyOG" class="icon custom-icon text brand_word_letter"
           mask="">
          <g transform="translate(-393.08618432117,-562.944415548383) rotate(0,707.94772199156,756.94772199156) scale(1,1)"
             style="" filter="" cursor="move" display="inline" opacity="1">
            <g style="" display="inline">
              <svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="1415.89544398312" height="1513.89544398312"
                   viewBox="0 0 1415.89544398312 1513.89544398312" data-ligature="true" preserveAspectRatio="none"
                   data-parent="shape_MBN9cAwyOG">
                <g transform="translate(631.2862765878476, 630.94772199156)">
                  <path
                    d="M65.20 0L18.09 0L18.09-156.48L63.10-156.48Q87.07-156.48 104.84-148.49Q122.62-140.49 132.50-123.46Q142.39-106.42 142.39-79.08L142.39-79.08Q142.39-51.95 132.61-34.39Q122.83-16.83 105.48-8.41Q88.12 0 65.20 0L65.20 0ZM55.73-126.61L55.73-30.29L60.78-30.29Q73.40-30.29 83.18-34.70Q92.96-39.12 98.43-49.85Q103.90-60.57 103.90-79.08L103.90-79.08Q103.90-97.80 98.43-108.10Q92.96-118.41 83.18-122.51Q73.40-126.61 60.78-126.61L60.78-126.61L55.73-126.61Z"
                    transform="translate(0 205) " fill="${e}" stroke="${e}" stroke-width="33.351"
                    stroke-miterlimit="3"></path>
                </g>
                <g transform="translate(631.2862765878476, 630.94772199156)">
                  <path
                    d="M65.20 0L18.09 0L18.09-156.48L63.10-156.48Q87.07-156.48 104.84-148.49Q122.62-140.49 132.50-123.46Q142.39-106.42 142.39-79.08L142.39-79.08Q142.39-51.95 132.61-34.39Q122.83-16.83 105.48-8.41Q88.12 0 65.20 0L65.20 0ZM55.73-126.61L55.73-30.29L60.78-30.29Q73.40-30.29 83.18-34.70Q92.96-39.12 98.43-49.85Q103.90-60.57 103.90-79.08L103.90-79.08Q103.90-97.80 98.43-108.10Q92.96-118.41 83.18-122.51Q73.40-126.61 60.78-126.61L60.78-126.61L55.73-126.61Z"
                    transform="translate(0 205) " fill="#ffffff" stroke="#ffffff" stroke-width="0.351"></path>
                </g>
              </svg>
            </g>
          </g>
        </g>
      </svg>
    </g>
  </g>
</svg>
`;return`data:image/svg+xml;charset=UTF-8,${encodeURIComponent(t)}`},pe={class:"font-weight-medium leading-normal text-xl text-uppercase"},be={__name:"NavHeader",setup(e){const t=Le();return(a,n)=>(v(),B(M,null,[L(G,{width:"3em",height:"2em",src:g(t)},null,8,["src"]),N("h1",pe,R(a.$t("global.title")),1)],64))}},Me=Z(be,[["__scopeId","data-v-ebb3b761"]]),$e={__name:"Github",setup(e){const{t}=w();return(a,n)=>Q((v(),p(y,{icon:"ri-github-line",color:"default",variant:"text",href:"https://github.com/miracleEverywhere/dst-management-platform-api",target:"_blank",rel:"noopener noreferrer"},null,512)),[[V,g(t)("global.github")]])}},Fe={__name:"LangSelect",setup(e){const t=w(),{current:a}=$(),n=F(),i=E(()=>n.language),o=x([]);A(()=>{u()});const u=()=>{n.language==="en"?o.value=[{label:"简体中文",value:"zh"},{label:"English",value:"en"}]:o.value=[{label:"简体中文",value:"zh"},{label:"English",value:"en"}]};k(()=>n.language,()=>{u()});const m=c=>{switch(t.locale.value=c,n.language=c,c){case"zh":a.value="zhHans";break;case"en":a.value="en";break;default:a.value="zhHans"}};return(c,d)=>(v(),p(ve,{"open-on-hover":""},{activator:b(({props:s})=>[L(y,S({color:"default",icon:"ri-translate-2",variant:"text"},s),null,16)]),default:b(()=>[L(ge,null,{default:b(()=>[(v(!0),B(M,null,z(g(o),s=>(v(),p(he,{key:s.value,command:s.value,disabled:g(i)===s.value,onClick:r=>m(s.value)},{default:b(()=>[O(R(s.label),1)]),_:2},1032,["command","disabled","onClick"]))),128))]),_:1})]),_:1}))}},Ee={__name:"Document",setup(e){const{t}=w();return(a,n)=>Q((v(),p(y,{icon:"ri-book-marked-line",color:"default",variant:"text",href:"https://miraclesses.top",target:"_blank",rel:"noopener noreferrer"},null,512)),[[V,g(t)("global.document")]])}};function _(e){return typeof e=="function"?e():g(e)}typeof WorkerGlobalScope<"u"&&globalThis instanceof WorkerGlobalScope;const _e=()=>{};function we(e,t){function a(...n){return new Promise((i,o)=>{Promise.resolve(e(()=>t.apply(this,n),{fn:t,thisArg:this,args:n})).then(i).catch(o)})}return a}const P=e=>e();function Qe(e=P){const t=x(!0);function a(){t.value=!1}function n(){t.value=!0}const i=(...o)=>{t.value&&e(...o)};return{isActive:I(t),pause:a,resume:n,eventFilter:i}}function ye(...e){if(e.length!==1)return H(...e);const t=e[0];return typeof t=="function"?I(W(()=>({get:t,set:_e}))):x(t)}function xe(e,t,a={}){const{eventFilter:n=P,...i}=a;return k(e,we(n,t),i)}function C(e,t,a={}){const{eventFilter:n,...i}=a,{eventFilter:o,pause:u,resume:m,isActive:c}=Qe(n);return{stop:xe(e,t,{...i,eventFilter:o}),pause:u,resume:m,isActive:c}}function Ae(e,t,...[a]){const{flush:n="sync",deep:i=!1,immediate:o=!0,direction:u="both",transform:m={}}=a||{},c=[],d="ltr"in m&&m.ltr||(l=>l),s="rtl"in m&&m.rtl||(l=>l);return(u==="both"||u==="ltr")&&c.push(C(e,l=>{c.forEach(f=>f.pause()),t.value=d(l),c.forEach(f=>f.resume())},{flush:n,deep:i,immediate:o})),(u==="both"||u==="rtl")&&c.push(C(t,l=>{c.forEach(f=>f.pause()),e.value=s(l),c.forEach(f=>f.resume())},{flush:n,deep:i,immediate:o})),()=>{c.forEach(l=>l.stop())}}function Ie(e=!1,t={}){const{truthyValue:a=!0,falsyValue:n=!1}=t,i=D(e),o=x(e);function u(m){if(arguments.length)return o.value=m,o.value;{const c=_(a);return o.value=o.value===c?_(n):c,o.value}}return i?u:[o,u]}function ke(e,t){const a=Y(d()),n=ye(e),i=E({get(){var s;const r=n.value;let l=t?.getIndexOf?t.getIndexOf(a.value,r):r.indexOf(a.value);return l<0&&(l=(s=t?.fallbackIndex)!=null?s:0),l},set(s){o(s)}});function o(s){const r=n.value,l=r.length,f=(s%l+l)%l,h=r[f];return a.value=h,h}function u(s=1){return o(i.value+s)}function m(s=1){return u(s)}function c(s=1){return u(-s)}function d(){var s,r;return(r=_((s=t?.initialValue)!=null?s:_(e)[0]))!=null?r:void 0}return k(n,()=>o(i.value)),{state:a,index:i,next:m,prev:c,go:o}}const Ne={__name:"ThemeSwitcher",props:{themes:{type:Array,required:!0}},setup(e){const t=e,a=F(),{t:n}=w(),{name:i,global:o}=T(),u=T(),{state:m,next:c,index:d}=ke(t.themes.map(r=>r.name),{initialValue:a.theme});A(()=>{a.theme===""?a.theme=u.global.name.value:(u.change(a.theme),document.documentElement.className=a.theme)});const s=async r=>{const l=()=>{const h=c();u.change(h),a.theme=h,document.documentElement.className=h};if(!document.startViewTransition){l();return}await document.startViewTransition(l).ready,document.documentElement.animate({opacity:[0,1]},{duration:300,easing:"ease-in-out",pseudoElement:"::view-transition-new(root)"}),document.documentElement.animate({opacity:[1,0]},{duration:300,easing:"ease-in-out",pseudoElement:"::view-transition-old(root)"})};return k(()=>u.global.name.value,r=>{m.value=r}),(r,l)=>Q((v(),p(y,{icon:t.themes[g(d)].icon,color:"default",variant:"text",onClick:s},null,8,["icon"])),[[V,g(n)("global."+g(a).theme)]])}},Pe={__name:"NavbarThemeSwitcher",setup(e){const t=[{name:"light",icon:"ri-sun-line"},{name:"dark",icon:"ri-moon-clear-line"}];return(a,n)=>{const i=Ne;return v(),p(i,{themes:t})}}},Se=J({bordered:Boolean,color:String,content:[Number,String],dot:Boolean,floating:Boolean,icon:ue,inline:Boolean,label:{type:String,default:"$vuetify.badge"},max:[Number,String],modelValue:{type:Boolean,default:!0},offsetX:[Number,String],offsetY:[Number,String],textColor:String,...ce(),...ie({location:"top end"}),...le(),...re(),...oe(),...se({transition:"scale-rotate-transition"}),...ne()},"VBadge"),Ze=q()({name:"VBadge",inheritAttrs:!1,props:Se(),setup(e,t){const{backgroundColorClasses:a,backgroundColorStyles:n}=K(()=>e.color),{roundedClasses:i}=U(e),{t:o}=$(),{textColorClasses:u,textColorStyles:m}=X(()=>e.textColor),{themeClasses:c}=T(),{locationStyles:d}=j(e,!0,r=>(e.floating?e.dot?2:4:e.dot?8:12)+(["top","bottom"].includes(r)?Number(e.offsetY??0):["left","right"].includes(r)?Number(e.offsetX??0):0)),{dimensionStyles:s}=ee(e);return te(()=>{const r=Number(e.content),l=!e.max||isNaN(r)?e.content:r<=Number(e.max)?r:`${e.max}+`,[f,h]=ae(t.attrs,["aria-atomic","aria-label","aria-live","role","title"]);return L(e.tag,S({class:["v-badge",{"v-badge--bordered":e.bordered,"v-badge--dot":e.dot,"v-badge--floating":e.floating,"v-badge--inline":e.inline},e.class]},h,{style:e.style}),{default:()=>[N("div",{class:"v-badge__wrapper"},[t.slots.default?.(),L(me,{transition:e.transition},{default:()=>[Q(N("span",S({class:["v-badge__badge",c.value,a.value,i.value,u.value],style:[n.value,m.value,s.value,e.inline?{}:d.value],"aria-atomic":"true","aria-label":o(e.label,r),"aria-live":"polite",role:"status"},f),[e.dot?void 0:t.slots.badge?t.slots.badge?.():e.icon?L(de,{icon:e.icon},null):l]),[[fe,e.modelValue]])]})])]})}),{}}});export{Me as N,Ze as V,$e as _,Ee as a,Fe as b,Pe as c,Ae as s,Ie as u};
