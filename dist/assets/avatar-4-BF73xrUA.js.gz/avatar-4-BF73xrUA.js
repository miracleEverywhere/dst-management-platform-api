const a="/assets/avatar-1-CxOKCzdw.png",s="/assets/avatar-2-DBHb2r0Y.png",t="/assets/avatar-3-BB5JHItX.png",r="/assets/avatar-4-x_MPl8Kx.png";export{a,s as b,t as c,r as d};
