/* empty css              */import{ak as a}from"./index-Bnu2ge-9.js";const p=a("v-spacer","div","VSpacer");export{p as V};
