import{_ as Z,c as V,o as g,a as y,k as I,l as h,m as G,t as $,F as E,b as w,z as k,A as L,s as Q,a2 as z,g as F,j as N,h as b,f as S,W as x,w as v,y as C,v as O,D,x as H,a3 as A,a4 as W,a5 as P,a6 as q,i as M}from"./index-Dko6h61I.js";import{T}from"./index-D4T6qB-n.js";import{V as J,a as K}from"./VList-X8Eeynlb.js";import{V as U}from"./VMenu-C2Sx5jJs.js";const Y=(t="#8C57FF")=>{const e=`
  <svg class="svg-canvas" viewBox="100 100 600 400" width="800" height="600" preserveAspectRatio="none" version="1.1"
     xmlns="http://www.w3.org/2000/svg">
  <g id="shape_Y1MFRqHJ6u" mask="">
    <g transform="translate(120,135.97354382365) rotate(0,280,164.02645617635) scale(1,1)"
       style="opacity: 1;mix-blend-mode: undefined;" filter="">
      <svg data-noselect="" viewBox="222.29009226667768 82.52330644317703 383.19672 224.48000000000002" width="560"
           height="328.05291235269" preserveAspectRatio="none" version="1.1" xmlns="http://www.w3.org/2000/svg"
           style="background: transparent;" class="style-removed" data-parent="shape_Y1MFRqHJ6u">
        <g id="shape_GhDKMseSsz" class="icon custom-icon text brand_word_letter" mask="">
          <g transform="translate(-195.58618432116998,-562.944415548383) rotate(0,703.44772199156,756.94772199156) scale(1,1)"
             style="" filter="" cursor="move" display="inline" opacity="1">
            <g style="" display="inline">
              <svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="1406.89544398312" height="1513.89544398312"
                   viewBox="0 0 1406.89544398312 1513.89544398312" data-ligature="true" preserveAspectRatio="none"
                   data-parent="shape_GhDKMseSsz">
                <g transform="translate(631.2029965878477, 630.94772199156)">
                  <path
                    d="M55.73 0L18.09 0L18.09-156.48L72.98-156.48Q90.23-156.48 104.53-151.85Q118.83-147.22 127.35-136.08Q135.87-124.93 135.87-105.58L135.87-105.58Q135.87-87.07 127.24-75.19Q118.62-63.31 104.63-57.63Q90.65-51.95 74.03-51.95L74.03-51.95L55.73-51.95L55.73 0ZM55.73-126.82L55.73-81.60L72.14-81.60Q85.81-81.60 92.54-87.81Q99.27-94.01 99.27-105.58L99.27-105.58Q99.27-117.36 92.02-122.09Q84.76-126.82 71.09-126.82L71.09-126.82L55.73-126.82Z"
                    transform="translate(0 205) " fill="${t}" stroke="${t}" stroke-width="33.351"
                    stroke-miterlimit="3"></path>
                </g>
                <g transform="translate(631.2029965878477, 630.94772199156)">
                  <path
                    d="M55.73 0L18.09 0L18.09-156.48L72.98-156.48Q90.23-156.48 104.53-151.85Q118.83-147.22 127.35-136.08Q135.87-124.93 135.87-105.58L135.87-105.58Q135.87-87.07 127.24-75.19Q118.62-63.31 104.63-57.63Q90.65-51.95 74.03-51.95L74.03-51.95L55.73-51.95L55.73 0ZM55.73-126.82L55.73-81.60L72.14-81.60Q85.81-81.60 92.54-87.81Q99.27-94.01 99.27-105.58L99.27-105.58Q99.27-117.36 92.02-122.09Q84.76-126.82 71.09-126.82L71.09-126.82L55.73-126.82Z"
                    transform="translate(0 205) " fill="#ffffff" stroke="#ffffff" stroke-width="0.351"></path>
                </g>
              </svg>
            </g>
          </g>
        </g>
        <g id="shape_m5SrZGu7uo" class="icon custom-icon text brand_word_letter"
           mask="">
          <g transform="translate(-312.08618432117,-562.944415548383) rotate(0,723.44772199156,756.94772199156) scale(1,1)"
             style="" filter="" cursor="move" display="inline" opacity="1">
            <g style="" display="inline">
              <svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="1446.89544398312" height="1513.89544398312"
                   viewBox="0 0 1446.89544398312 1513.89544398312" data-ligature="true" preserveAspectRatio="none"
                   data-parent="shape_m5SrZGu7uo">
                <g transform="translate(631.2225965878476, 630.94772199156)">
                  <path
                    d="M51.74 0L18.09 0L18.09-156.48L58.68-156.48L83.50-88.97Q86.44-80.13 89.18-70.67L89.18-70.67Q90.65-65.62 92.12-60.36L92.12-60.36L93.17-60.36Q95.49-67.72 97.59-75.29L97.59-75.29Q99.69-82.24 101.79-88.97L101.79-88.97L125.77-156.48L166.57-156.48L166.57 0L132.29 0L132.29-53.63Q132.29-64.99 133.87-79.71Q135.45-94.43 136.92-106.42L136.92-106.42Q137.13-107.26 137.13-107.89L137.13-107.89L136.29-107.89L123.25-70.46L102.22-13.25L81.60-13.25L60.36-70.46L47.74-107.89L46.90-107.89Q46.90-107.26 47.11-106.42L47.11-106.42Q48.58-94.43 50.16-79.71Q51.74-64.99 51.74-53.63L51.74-53.63L51.74 0Z"
                    transform="translate(0 205) " fill="${t}" stroke="${t}" stroke-width="33.351"
                    stroke-miterlimit="3"></path>
                </g>
                <g transform="translate(631.2225965878476, 630.94772199156)">
                  <path
                    d="M51.74 0L18.09 0L18.09-156.48L58.68-156.48L83.50-88.97Q86.44-80.13 89.18-70.67L89.18-70.67Q90.65-65.62 92.12-60.36L92.12-60.36L93.17-60.36Q95.49-67.72 97.59-75.29L97.59-75.29Q99.69-82.24 101.79-88.97L101.79-88.97L125.77-156.48L166.57-156.48L166.57 0L132.29 0L132.29-53.63Q132.29-64.99 133.87-79.71Q135.45-94.43 136.92-106.42L136.92-106.42Q137.13-107.26 137.13-107.89L137.13-107.89L136.29-107.89L123.25-70.46L102.22-13.25L81.60-13.25L60.36-70.46L47.74-107.89L46.90-107.89Q46.90-107.26 47.11-106.42L47.11-106.42Q48.58-94.43 50.16-79.71Q51.74-64.99 51.74-53.63L51.74-53.63L51.74 0Z"
                    transform="translate(0 205) " fill="#ffffff" stroke="#ffffff" stroke-width="0.351"></path>
                </g>
              </svg>
            </g>
          </g>
        </g>
        <g id="shape_MBN9cAwyOG" class="icon custom-icon text brand_word_letter"
           mask="">
          <g transform="translate(-393.08618432117,-562.944415548383) rotate(0,707.94772199156,756.94772199156) scale(1,1)"
             style="" filter="" cursor="move" display="inline" opacity="1">
            <g style="" display="inline">
              <svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="1415.89544398312" height="1513.89544398312"
                   viewBox="0 0 1415.89544398312 1513.89544398312" data-ligature="true" preserveAspectRatio="none"
                   data-parent="shape_MBN9cAwyOG">
                <g transform="translate(631.2862765878476, 630.94772199156)">
                  <path
                    d="M65.20 0L18.09 0L18.09-156.48L63.10-156.48Q87.07-156.48 104.84-148.49Q122.62-140.49 132.50-123.46Q142.39-106.42 142.39-79.08L142.39-79.08Q142.39-51.95 132.61-34.39Q122.83-16.83 105.48-8.41Q88.12 0 65.20 0L65.20 0ZM55.73-126.61L55.73-30.29L60.78-30.29Q73.40-30.29 83.18-34.70Q92.96-39.12 98.43-49.85Q103.90-60.57 103.90-79.08L103.90-79.08Q103.90-97.80 98.43-108.10Q92.96-118.41 83.18-122.51Q73.40-126.61 60.78-126.61L60.78-126.61L55.73-126.61Z"
                    transform="translate(0 205) " fill="${t}" stroke="${t}" stroke-width="33.351"
                    stroke-miterlimit="3"></path>
                </g>
                <g transform="translate(631.2862765878476, 630.94772199156)">
                  <path
                    d="M65.20 0L18.09 0L18.09-156.48L63.10-156.48Q87.07-156.48 104.84-148.49Q122.62-140.49 132.50-123.46Q142.39-106.42 142.39-79.08L142.39-79.08Q142.39-51.95 132.61-34.39Q122.83-16.83 105.48-8.41Q88.12 0 65.20 0L65.20 0ZM55.73-126.61L55.73-30.29L60.78-30.29Q73.40-30.29 83.18-34.70Q92.96-39.12 98.43-49.85Q103.90-60.57 103.90-79.08L103.90-79.08Q103.90-97.80 98.43-108.10Q92.96-118.41 83.18-122.51Q73.40-126.61 60.78-126.61L60.78-126.61L55.73-126.61Z"
                    transform="translate(0 205) " fill="#ffffff" stroke="#ffffff" stroke-width="0.351"></path>
                </g>
              </svg>
            </g>
          </g>
        </g>
      </svg>
    </g>
  </g>
</svg>
`;return`data:image/svg+xml;charset=UTF-8,${encodeURIComponent(e)}`},j={class:"font-weight-medium leading-normal text-xl text-uppercase"},X={__name:"NavHeader",setup(t){const e=Y();return(a,n)=>(g(),V(E,null,[y(G,{width:"3em",height:"2em",src:h(e)},null,8,["src"]),I("h1",j,$(a.$t("global.title")),1)],64))}},me=Z(X,[["__scopeId","data-v-bfb49ee7"]]),fe={__name:"Github",setup(t){const{t:e}=w();return(a,n)=>k((g(),L(Q,{icon:"ri-github-line",color:"default",variant:"text",href:"https://github.com/miracleEverywhere/dst-management-platform-api",target:"_blank",rel:"noopener noreferrer"},null,512)),[[T,h(e)("global.github")]])}},he={__name:"LangSelect",setup(t){const e=w(),{current:a}=z(),n=F(),o=N(()=>n.language),r=b([]);S(()=>{c()});const c=()=>{n.language==="en"?r.value=[{label:"简体中文",value:"zh"},{label:"English",value:"en"}]:r.value=[{label:"简体中文",value:"zh"},{label:"English",value:"en"}]};x(()=>n.language,()=>{c()},{deep:!0});const m=l=>{switch(e.locale.value=l,n.language=l,l){case"zh":a.value="zhHans";break;case"en":a.value="en";break;default:a.value="zhHans"}};return(l,p)=>(g(),L(U,{"open-on-hover":""},{activator:v(({props:s})=>[y(Q,D({color:"default",icon:"ri-translate-2",variant:"text"},s),null,16)]),default:v(()=>[y(J,null,{default:v(()=>[(g(!0),V(E,null,C(h(r),s=>(g(),L(K,{key:s.value,command:s.value,disabled:h(o)===s.value,onClick:u=>m(s.value)},{default:v(()=>[O($(s.label),1)]),_:2},1032,["command","disabled","onClick"]))),128))]),_:1})]),_:1}))}},ge={__name:"Document",setup(t){const{t:e}=w();return(a,n)=>k((g(),L(Q,{icon:"ri-book-marked-line",color:"default",variant:"text",href:"https://miraclesses.top/",target:"_blank",rel:"noopener noreferrer"},null,512)),[[T,h(e)("global.document")]])}};function _(t){return typeof t=="function"?t():h(t)}typeof WorkerGlobalScope<"u"&&globalThis instanceof WorkerGlobalScope;const ee=()=>{};function te(t,e){function a(...n){return new Promise((o,r)=>{Promise.resolve(t(()=>e.apply(this,n),{fn:e,thisArg:this,args:n})).then(o).catch(r)})}return a}const B=t=>t();function ae(t=B){const e=b(!0);function a(){e.value=!1}function n(){e.value=!0}const o=(...r)=>{e.value&&t(...r)};return{isActive:A(e),pause:a,resume:n,eventFilter:o}}function ne(...t){if(t.length!==1)return W(...t);const e=t[0];return typeof e=="function"?A(P(()=>({get:e,set:ee}))):b(e)}function se(t,e,a={}){const{eventFilter:n=B,...o}=a;return x(t,te(n,e),o)}function R(t,e,a={}){const{eventFilter:n,...o}=a,{eventFilter:r,pause:c,resume:m,isActive:l}=ae(n);return{stop:se(t,e,{...o,eventFilter:r}),pause:c,resume:m,isActive:l}}function pe(t,e,...[a]){const{flush:n="sync",deep:o=!1,immediate:r=!0,direction:c="both",transform:m={}}=a||{},l=[],p="ltr"in m&&m.ltr||(i=>i),s="rtl"in m&&m.rtl||(i=>i);return(c==="both"||c==="ltr")&&l.push(R(t,i=>{l.forEach(f=>f.pause()),e.value=p(i),l.forEach(f=>f.resume())},{flush:n,deep:o,immediate:r})),(c==="both"||c==="rtl")&&l.push(R(e,i=>{l.forEach(f=>f.pause()),t.value=s(i),l.forEach(f=>f.resume())},{flush:n,deep:o,immediate:r})),()=>{l.forEach(i=>i.stop())}}function de(t=!1,e={}){const{truthyValue:a=!0,falsyValue:n=!1}=e,o=H(t),r=b(t);function c(m){if(arguments.length)return r.value=m,r.value;{const l=_(a);return r.value=r.value===l?_(n):l,r.value}}return o?c:[r,c]}function re(t,e){const a=q(p()),n=ne(t),o=N({get(){var s;const u=n.value;let i=e?.getIndexOf?e.getIndexOf(a.value,u):u.indexOf(a.value);return i<0&&(i=(s=e?.fallbackIndex)!=null?s:0),i},set(s){r(s)}});function r(s){const u=n.value,i=u.length,f=(s%i+i)%i,d=u[f];return a.value=d,d}function c(s=1){return r(o.value+s)}function m(s=1){return c(s)}function l(s=1){return c(-s)}function p(){var s,u;return(u=_((s=e?.initialValue)!=null?s:_(t)[0]))!=null?u:void 0}return x(n,()=>r(o.value)),{state:a,index:o,next:m,prev:l,go:r}}const oe={__name:"ThemeSwitcher",props:{themes:{type:Array,required:!0}},setup(t){const e=t,a=F(),{t:n}=w(),{name:o,global:r}=M(),c=M(),{state:m,next:l,index:p}=re(e.themes.map(u=>u.name),{initialValue:a.theme});S(()=>{a.theme===""?a.theme=c.global.name.value:(c.change(a.theme),document.documentElement.className=a.theme)});const s=async u=>{const i=()=>{const d=l();c.change(d),a.theme=d,document.documentElement.className=d};if(!document.startViewTransition){i();return}await document.startViewTransition(i).ready,document.documentElement.animate({opacity:[0,1]},{duration:300,easing:"ease-in-out",pseudoElement:"::view-transition-new(root)"}),document.documentElement.animate({opacity:[1,0]},{duration:300,easing:"ease-in-out",pseudoElement:"::view-transition-old(root)"})};return x(()=>c.global.name.value,u=>{m.value=u}),(u,i)=>k((g(),L(Q,{icon:e.themes[h(p)].icon,color:"default",variant:"text",onClick:s},null,8,["icon"])),[[T,h(n)("global."+h(a).theme)]])}},Le={__name:"NavbarThemeSwitcher",setup(t){const e=[{name:"light",icon:"ri-sun-line"},{name:"dark",icon:"ri-moon-clear-line"}];return(a,n)=>{const o=oe;return g(),L(o,{themes:e})}}};export{me as N,fe as _,ge as a,he as b,Le as c,pe as s,de as u};
